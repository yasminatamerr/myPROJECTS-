% Simscape(TM) Multibody(TM) version: 7.6

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(93).translation = [0.0 0.0 0.0];
smiData.RigidTransform(93).angle = 0.0;
smiData.RigidTransform(93).axis = [0.0 0.0 0.0];
smiData.RigidTransform(93).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [38.084896083057991 84.447902240043845 134.32888928476837];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = "B[ScaraBase-1:-:GT2 Pulley - Parametric-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-9.3365506703118135e-15 4.5000000000000018 -3.4278364458274844e-14];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(2).ID = "F[ScaraBase-1:-:GT2 Pulley - Parametric-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0.17483508378737619 -19.669440683030714 51.547223212998766];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962573 -0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(3).ID = "B[Link4-2:-:GT2 Pulley - Parametric-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [7.1731913058785018e-10 8.7000000000000028 -5.4721733525895842e-10];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(4).axis = [0.57735026918962595 -0.5773502691896254 0.57735026918962595];
smiData.RigidTransform(4).ID = "F[Link4-2:-:GT2 Pulley - Parametric-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 379.99999999999994 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = "B[Lead Screw D8mm L380mm-4:-:Link3-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-68.930510075700965 162.02347734133889 -290.77522145568923];  % mm
smiData.RigidTransform(6).angle = 6.2142744146760518e-15;  % rad
smiData.RigidTransform(6).axis = [-0.79325410222225934 0.6088907367562405 -1.5007630390484837e-15];
smiData.RigidTransform(6).ID = "F[Lead Screw D8mm L380mm-4:-:Link3-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [125.14119000747031 375.79696367283253 77.611273327470798];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(7).ID = "B[FirstR-1:-:Lead Screw D8mm L380mm-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [8.2740668279554536e-12 378.69618324129118 -1.3013196961814438e-11];  % mm
smiData.RigidTransform(8).angle = 2.094395102393197;  % rad
smiData.RigidTransform(8).axis = [-0.5773502691896264 -0.5773502691896254 -0.57735026918962562];
smiData.RigidTransform(8).ID = "F[FirstR-1:-:Lead Screw D8mm L380mm-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [123.58345512306929 -40.669440683030686 122.79722321299965];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(9).ID = "B[Link4-2:-:DrillingEE-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [27.649393826821495 34.352286820450473 52.397399959326336];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(10).axis = [-0.57735026918962562 -0.57735026918962595 -0.57735026918962562];
smiData.RigidTransform(10).ID = "F[Link4-2:-:DrillingEE-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-68.930510075702273 357.02347734134003 42.728595303018814];  % mm
smiData.RigidTransform(11).angle = 4.6790994441018353e-15;  % rad
smiData.RigidTransform(11).axis = [-0.66436383882991978 0.74740931868365967 -1.1617074481908003e-15];
smiData.RigidTransform(11).ID = "B[Link3-2:-:Link4-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [5.3709875057237113 25.630559316969268 54.547223213492053];  % mm
smiData.RigidTransform(12).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962584 -0.57735026918962595 0.5773502691896254];
smiData.RigidTransform(12).ID = "F[Link3-2:-:Link4-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [152.38507309465712 13.7969636728327 72.073364546699324];  % mm
smiData.RigidTransform(13).angle = 2.0943951023932055;  % rad
smiData.RigidTransform(13).axis = [0.57735026918962906 0.57735026918962906 0.57735026918961907];
smiData.RigidTransform(13).ID = "B[FirstR-1:-:Link3-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-63.392601294919473 189.26736042853946 72.528595303019344];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931908;  % rad
smiData.RigidTransform(14).axis = [-0.5773502691896224 0.57735026918963239 0.57735026918962251];
smiData.RigidTransform(14).ID = "F[FirstR-1:-:Link3-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [151.78234427312941 500.61352360301612 183.59202792324425];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931939;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962518 -0.57735026918962573 0.5773502691896264];
smiData.RigidTransform(15).ID = "B[:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [151.78234427312941 500.61352360301612 183.59202792324425];  % mm
smiData.RigidTransform(16).angle = 2.0943951023931939;  % rad
smiData.RigidTransform(16).axis = [0.57735026918962518 -0.57735026918962573 0.5773502691896264];
smiData.RigidTransform(16).ID = "F[:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [70.826627078787624 77.813221026000619 164.50303469774209];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(17).ID = "B[ScaraBase-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [40.021423389504434 63.478842388972836 179.6269222680678];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(18).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(18).ID = "F[ScaraBase-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [125.14119000746734 33.796963672832689 77.611273327475118];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = "B[FirstR-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [152.0214233895143 152.11352360301606 179.626922268062];  % mm
smiData.RigidTransform(20).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(20).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(20).ID = "F[FirstR-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [149.82662707878762 111.64790224004386 164.50303469774215];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = "B[ScaraBase-1:-:FirstR-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [92.141190007457482 -21.00303632716728 77.611273327480973];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(22).ID = "F[ScaraBase-1:-:FirstR-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [70.826627078787624 77.813221026000619 164.50303469774209];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(23).ID = "B[ScaraBase-1:-:GT2 Pulley - 22 - 80 teeth-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-1.638279921770192e-13 -0.53468121404347357 2.5997256650566528e-14];  % mm
smiData.RigidTransform(24).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(24).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(24).ID = "F[ScaraBase-1:-:GT2 Pulley - 22 - 80 teeth-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [125.14119000747269 396.29696367283179 77.61127332747121];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(25).axis = [-0.57735026918962595 -0.57735026918962429 -0.57735026918962706];
smiData.RigidTransform(25).ID = "B[FirstR-1:-:Stepper NEMA 17 -  20mm shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [8.4613756492643404 37.229085012037231 71.016147736674711];  % mm
smiData.RigidTransform(26).angle = 3.1415926535897896;  % rad
smiData.RigidTransform(26).axis = [1 1.5777218104420219e-30 8.8817841970012484e-16];
smiData.RigidTransform(26).ID = "F[FirstR-1:-:Stepper NEMA 17 -  20mm shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [27.649393826401024 15.352286820450505 52.397399960453669];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931944;  % rad
smiData.RigidTransform(27).axis = [-0.57735026918962551 -0.57735026918962551 -0.57735026918962629];
smiData.RigidTransform(27).ID = "B[DrillingEE-1:-:drill bit-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-1.7147646299592447e-10 -2.8637071361244846e-10 -2.842170943112779e-14];  % mm
smiData.RigidTransform(28).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(28).axis = [-1 2.9253863673999546e-32 -1.1602063317757287e-16];
smiData.RigidTransform(28).ID = "F[DrillingEE-1:-:drill bit-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [17.972694518654478 167.47404997671856 166.78037610656972];  % mm
smiData.RigidTransform(29).angle = 2.5983788196333468;  % rad
smiData.RigidTransform(29).axis = [0.27848890597540982 0.67913324511785578 -0.67913324511785578];
smiData.RigidTransform(29).ID = "AssemblyGround[ScaraBase-1:Stepper NEMA 17 -  20mm shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [70.82662707878761 107.44790224004387 164.50303469774209];  % mm
smiData.RigidTransform(30).angle = 0.18658806758865501;  % rad
smiData.RigidTransform(30).axis = [0 1 0];
smiData.RigidTransform(30).ID = "AssemblyGround[ScaraBase-1:Ball Bearing 608 - 8x22x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [107.32662707878764 104.44790224004387 164.50303469774218];  % mm
smiData.RigidTransform(31).angle = 0;  % rad
smiData.RigidTransform(31).axis = [0 0 0];
smiData.RigidTransform(31).ID = "AssemblyGround[ScaraBase-1:Base-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [149.82662707878762 91.447902240043874 164.50303469774218];  % mm
smiData.RigidTransform(32).angle = 0;  % rad
smiData.RigidTransform(32).axis = [0 0 0];
smiData.RigidTransform(32).ID = "AssemblyGround[ScaraBase-1:Thrust Bearing - 40x60x13-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [70.826627078787595 114.44790224004386 164.50303469774204];  % mm
smiData.RigidTransform(33).angle = 2.0401271071358056;  % rad
smiData.RigidTransform(33).axis = [-0 -1 -0];
smiData.RigidTransform(33).ID = "AssemblyGround[ScaraBase-1:M8 Lock nut-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [70.82662707878761 96.947902240043859 164.50303469774215];  % mm
smiData.RigidTransform(34).angle = 0.21634772122027721;  % rad
smiData.RigidTransform(34).axis = [0 1 0];
smiData.RigidTransform(34).ID = "AssemblyGround[ScaraBase-1:Ball Bearing 608 - 8x22x7mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [70.826627078787624 97.663221026000613 164.50303469774209];  % mm
smiData.RigidTransform(35).angle = 1.5709142750194642;  % rad
smiData.RigidTransform(35).axis = [-0.01085975663407158 -0.01085975663407158 0.99988205873077718];
smiData.RigidTransform(35).ID = "AssemblyGround[ScaraBase-1:M8 45mm - Bolts-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [149.82662707878762 104.64790224004386 164.50303469774215];  % mm
smiData.RigidTransform(36).angle = 0.23458965056264272;  % rad
smiData.RigidTransform(36).axis = [0 1 0];
smiData.RigidTransform(36).ID = "AssemblyGround[ScaraBase-1:Ball Bearing 35x47x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [27.649393826401024 52.152286820450477 52.397399960453669];  % mm
smiData.RigidTransform(37).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(37).axis = [0.091460684934861661 -5.3408808110413414e-17 0.99580868800751388];
smiData.RigidTransform(37).ID = "AssemblyGround[DrillingEE-1:Thrust Bearing 35x52x12mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [27.649393826401024 40.352286820450473 52.397399960453669];  % mm
smiData.RigidTransform(38).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(38).axis = [-0.28073332447336352 -2.8172683940741409e-17 0.95978580971492444];
smiData.RigidTransform(38).ID = "AssemblyGround[DrillingEE-1:Ball Bearing 30x42x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [27.649393826401024 50.35228682045048 52.397399960453669];  % mm
smiData.RigidTransform(39).angle = 1.9077765091869279;  % rad
smiData.RigidTransform(39).axis = [5.4023790746726391e-16 -1 -8.0012447310198938e-16];
smiData.RigidTransform(39).ID = "AssemblyGround[DrillingEE-1:GT2 Pulley - 90 teeth - J3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [27.649393826401024 15.352286820450505 52.397399960453669];  % mm
smiData.RigidTransform(40).angle = 2.8172266642267854;  % rad
smiData.RigidTransform(40).axis = [1.454543038181538e-16 1 8.3001792465975828e-16];
smiData.RigidTransform(40).ID = "AssemblyGround[DrillingEE-1:J3 Coupler-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [27.649393826401024 33.35228682045048 52.397399960453669];  % mm
smiData.RigidTransform(41).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(41).axis = [-0.45963344445855786 -3.0446432615642536e-17 0.88810871898386512];
smiData.RigidTransform(41).ID = "AssemblyGround[DrillingEE-1:Thrust Bearing 35x52x12mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [16.370987506493904 43.130559316969354 54.547223212998652];  % mm
smiData.RigidTransform(42).angle = 0.29668992116572074;  % rad
smiData.RigidTransform(42).axis = [0 1 0];
smiData.RigidTransform(42).ID = "AssemblyGround[Link4-2:M4 Lock nut-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [130.07864565145255 -41.669440683030686 126.54722321299971];  % mm
smiData.RigidTransform(43).angle = 0.52359877559830648;  % rad
smiData.RigidTransform(43).axis = [2.9380623224780987e-16 -1 0];
smiData.RigidTransform(43).ID = "AssemblyGround[Link4-2:Arm 2 Cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [0.174835083787378 -65.669440683030714 51.547223212998759];  % mm
smiData.RigidTransform(44).angle = 0.52359877559830603;  % rad
smiData.RigidTransform(44).axis = [2.9183403287407717e-16 -1 0];
smiData.RigidTransform(44).ID = "AssemblyGround[Link4-2:NEMA 17 Stepper L24mm - 20mm shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [5.3709875064939521 34.930559316969337 54.547223212998652];  % mm
smiData.RigidTransform(45).angle = 0;  % rad
smiData.RigidTransform(45).axis = [0 0 0];
smiData.RigidTransform(45).ID = "AssemblyGround[Link4-2:GT2 Pulley - 92 teeth - J2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [5.3709875064940071 -2.6694406830306825 54.547223212998766];  % mm
smiData.RigidTransform(46).angle = 1.5707963267948821;  % rad
smiData.RigidTransform(46).axis = [6.0690924558028808e-17 1 6.0690924558029128e-17];
smiData.RigidTransform(46).ID = "AssemblyGround[Link4-2:J2 Coupler-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [-5.6290124935060586 43.130559316969354 54.547223212998652];  % mm
smiData.RigidTransform(47).angle = 0.42232240204964377;  % rad
smiData.RigidTransform(47).axis = [0 1 0];
smiData.RigidTransform(47).ID = "AssemblyGround[Link4-2:M4 Lock nut-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [5.3709875064939796 43.130559316969325 43.547223212998645];  % mm
smiData.RigidTransform(48).angle = 0.57132144620425029;  % rad
smiData.RigidTransform(48).axis = [0 1 0];
smiData.RigidTransform(48).ID = "AssemblyGround[Link4-2:M4 Lock nut-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [5.3709875064940071 0.33055931696934771 65.547223212998659];  % mm
smiData.RigidTransform(49).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(49).axis = [1 0 0];
smiData.RigidTransform(49).ID = "AssemblyGround[Link4-2:M4 50mm - Bolts-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [130.0786456514526 -2.6694406830306825 126.54722321299971];  % mm
smiData.RigidTransform(50).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(50).axis = [-0.96592582628906731 -0 -0.25881904510252446];
smiData.RigidTransform(50).ID = "AssemblyGround[Link4-2:Arm 2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [-5.6290124935060586 0.33055931696931995 54.547223212998652];  % mm
smiData.RigidTransform(51).angle = 1.5846507378773671;  % rad
smiData.RigidTransform(51).axis = [0.98624068245190766 -0.11689592866476436 0.11689592866476436];
smiData.RigidTransform(51).ID = "AssemblyGround[Link4-2:M4 50mm - Bolts-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [5.3709875064939796 43.130559316969354 65.547223212998716];  % mm
smiData.RigidTransform(52).angle = 0.43289740767976653;  % rad
smiData.RigidTransform(52).axis = [0 1 0];
smiData.RigidTransform(52).ID = "AssemblyGround[Link4-2:M4 Lock nut-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [5.3709875064939796 0.33055931696931995 43.547223212998645];  % mm
smiData.RigidTransform(53).angle = 1.7772495577734366;  % rad
smiData.RigidTransform(53).axis = [0.81225929413599096 -0.41245293009609085 0.4124529300960908];
smiData.RigidTransform(53).ID = "AssemblyGround[Link4-2:M4 50mm - Bolts-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [16.370987506493961 0.33055931696934771 54.547223212998652];  % mm
smiData.RigidTransform(54).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(54).axis = [1 0 0];
smiData.RigidTransform(54).ID = "AssemblyGround[Link4-2:M4 50mm - Bolts-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [5.3709875064940071 4.0305593169692733 54.547223212998766];  % mm
smiData.RigidTransform(55).angle = 0.61364386559891748;  % rad
smiData.RigidTransform(55).axis = [8.3268345467212507e-16 -1 2.7812055203476046e-15];
smiData.RigidTransform(55).ID = "AssemblyGround[Link4-2:Thrust Bearing 35x52x12mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [-68.930510075701591 129.02347734133994 7.5285953030196362];  % mm
smiData.RigidTransform(56).angle = 3.1415926535897882;  % rad
smiData.RigidTransform(56).axis = [-1.394522238736837e-31 -0.70710678118654879 -0.70710678118654624];
smiData.RigidTransform(56).ID = "AssemblyGround[Link3-2:Z-axis Mount Platform-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [-68.930510075702216 357.02347734134008 52.528595303018818];  % mm
smiData.RigidTransform(57).angle = 2.0943951023931975;  % rad
smiData.RigidTransform(57).axis = [-0.5773502691896244 -0.57735026918962462 0.57735026918962828];
smiData.RigidTransform(57).ID = "AssemblyGround[Link3-2:Arm 1-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [-68.930510075701974 267.02347734134003 45.528595303019088];  % mm
smiData.RigidTransform(58).angle = 1.8377360025019811;  % rad
smiData.RigidTransform(58).axis = [0.76325159542505694 0.45686267197107983 0.45686267197107566];
smiData.RigidTransform(58).ID = "AssemblyGround[Link3-2:Ball Bearing 608 - 8x22x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [-60.46913442642726 156.25256235339182 -53.497552433655144];  % mm
smiData.RigidTransform(59).angle = 3.14159265358979;  % rad
smiData.RigidTransform(59).axis = [-1.706238630663766e-15 -1.9433701591279575e-15 -1];
smiData.RigidTransform(59).ID = "AssemblyGround[Link3-2:Stepper NEMA 17 -  20mm shaft-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [-68.930510075702387 357.02347734133986 7.528595303018804];  % mm
smiData.RigidTransform(60).angle = 2.094395102393197;  % rad
smiData.RigidTransform(60).axis = [0.57735026918962462 0.57735026918962828 0.57735026918962451];
smiData.RigidTransform(60).ID = "AssemblyGround[Link3-2:Arm 1 Cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [-68.930510075701861 267.02347734133986 35.378595303019154];  % mm
smiData.RigidTransform(61).angle = 1.7367657294332037;  % rad
smiData.RigidTransform(61).axis = [-0.37654281147804591 -0.84642248448893465 -0.37654281147804169];
smiData.RigidTransform(61).ID = "AssemblyGround[Link3-2:M8 45mm - Bolts-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [-68.930510075702301 357.02347734134003 30.528595303018825];  % mm
smiData.RigidTransform(62).angle = 1.6093670294002707;  % rad
smiData.RigidTransform(62).axis = [0.9621544697280382 -0.1926898756841631 -0.19268987568416582];
smiData.RigidTransform(62).ID = "AssemblyGround[Link3-2:Thrust Bearing 35x52x12mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [-68.930510075701861 267.02347734133991 52.528595303019152];  % mm
smiData.RigidTransform(63).angle = 2.746740655072113;  % rad
smiData.RigidTransform(63).axis = [0.20003165717805432 0.6928157533307846 0.69281575333078171];
smiData.RigidTransform(63).ID = "AssemblyGround[Link3-2:M8 Lock nut-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-68.930510075701946 267.02347734133997 36.528595303019138];  % mm
smiData.RigidTransform(64).angle = 3.0680309793325544;  % rad
smiData.RigidTransform(64).axis = [0.036797432181839854 -0.7066278896933047 -0.70662788969330237];
smiData.RigidTransform(64).ID = "AssemblyGround[Link3-2:Ball Bearing 608 - 8x22x7mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [-68.930510075702244 357.02347734134003 49.728595303018821];  % mm
smiData.RigidTransform(65).angle = 1.5707963545056967;  % rad
smiData.RigidTransform(65).axis = [-0.99999997228920368 -0.0001664656000228763 0.00016646560002637405];
smiData.RigidTransform(65).ID = "AssemblyGround[Link3-2:Ball Bearing 30x42x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [92.141190007469987 2.2969636728327609 77.611273327472716];  % mm
smiData.RigidTransform(66).angle = 1.5707963267949141;  % rad
smiData.RigidTransform(66).axis = [7.0798472898056398e-16 1 7.0798472898056388e-16];
smiData.RigidTransform(66).ID = "AssemblyGround[FirstR-1:Z-axis Bottom Plate-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [58.553617901112986 382.29696367283179 111.19884543383453];  % mm
smiData.RigidTransform(67).angle = 0.78539816339741819;  % rad
smiData.RigidTransform(67).axis = [1.568915840240303e-15 -1 -6.0415641638217324e-15];
smiData.RigidTransform(67).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [92.14119000747003 -38.903036327167278 77.611273327472659];  % mm
smiData.RigidTransform(68).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(68).axis = [4.4001621622858993e-15 -5.5650114842963822e-16 1];
smiData.RigidTransform(68).ID = "AssemblyGround[FirstR-1:GT2 Pulley - 110 teeth - J1-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [58.553617901110485 382.29696367283202 44.02370122111239];  % mm
smiData.RigidTransform(69).angle = 2.3561944901923115;  % rad
smiData.RigidTransform(69).axis = [-3.4180520676778675e-16 -1 -1.3849660069455973e-15];
smiData.RigidTransform(69).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-10]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [125.72876211383479 396.29696367283179 111.19884543383225];  % mm
smiData.RigidTransform(70).angle = 3.1415926535897905;  % rad
smiData.RigidTransform(70).axis = [0.38268343236510638 -1.8642660946049654e-15 0.92387953251127986];
smiData.RigidTransform(70).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-11]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [79.641190007468921 -0.70303632716731124 77.611273327473981];  % mm
smiData.RigidTransform(71).angle = 2.9341041581660732;  % rad
smiData.RigidTransform(71).axis = [-0.10411805232530497 -0.70326361742236609 -0.70326361742236665];
smiData.RigidTransform(71).ID = "AssemblyGround[FirstR-1:M4 60mm - Bolts-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(72).translation = [92.141190007468865 -47.103036327167295 90.111273327473882];  % mm
smiData.RigidTransform(72).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(72).axis = [0.1758434546338386 0 0.98441814259106231];
smiData.RigidTransform(72).ID = "AssemblyGround[FirstR-1:M4 Lock nut-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(73).translation = [104.64119000746891 -0.70303632716731124 77.611273327473938];  % mm
smiData.RigidTransform(73).angle = 2.9341041581660732;  % rad
smiData.RigidTransform(73).axis = [-0.10411805232530497 -0.70326361742236609 -0.70326361742236665];
smiData.RigidTransform(73).ID = "AssemblyGround[FirstR-1:M4 60mm - Bolts-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(74).translation = [92.141190007467344 33.796963672832689 77.611273327475686];  % mm
smiData.RigidTransform(74).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(74).axis = [1 0 -8.659739592076221e-15];
smiData.RigidTransform(74).ID = "AssemblyGround[FirstR-1:Base cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(75).translation = [92.14119000746895 -5.7030363271672879 77.611273327473981];  % mm
smiData.RigidTransform(75).angle = 0;  % rad
smiData.RigidTransform(75).axis = [0 0 0];
smiData.RigidTransform(75).ID = "AssemblyGround[FirstR-1:J1 coupler-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(76).translation = [125.72876211383166 26.296963672832685 111.19884543383303];  % mm
smiData.RigidTransform(76).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(76).axis = [-0.38268343236509833 1.6033430985632683e-16 -0.9238795325112833];
smiData.RigidTransform(76).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-5]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(77).translation = [58.55361790110949 26.296963672832685 111.19884543383417];  % mm
smiData.RigidTransform(77).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(77).axis = [-0.38268343236508318 1.4518151706880165e-16 0.92387953251128951];
smiData.RigidTransform(77).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-6]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(78).translation = [58.553617901108339 -3.7030363271672586 44.023701221112283];  % mm
smiData.RigidTransform(78).angle = 1.4485906954913146;  % rad
smiData.RigidTransform(78).axis = [1.881046077285926e-15 1 1.2564143308001493e-16];
smiData.RigidTransform(78).ID = "AssemblyGround[FirstR-1:Smooth Rod D10mm L400mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(79).translation = [125.72876211383071 -3.7030363271673137 44.023701221111473];  % mm
smiData.RigidTransform(79).angle = 1.685832852423063;  % rad
smiData.RigidTransform(79).axis = [1.5933636657926268e-15 -1 -1.3763357548577321e-15];
smiData.RigidTransform(79).ID = "AssemblyGround[FirstR-1:Smooth Rod D10mm L400mm-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(80).translation = [125.72876211383071 26.296963672832796 44.023701221111473];  % mm
smiData.RigidTransform(80).angle = 3.1415926535897905;  % rad
smiData.RigidTransform(80).axis = [-0.92387953251128807 3.7192847258134723e-16 -0.38268343236508667];
smiData.RigidTransform(80).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-7]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(81).translation = [125.72876211383169 -3.7030363271673137 111.19884543383297];  % mm
smiData.RigidTransform(81).angle = 1.2505294926581259;  % rad
smiData.RigidTransform(81).axis = [0 1 0];
smiData.RigidTransform(81).ID = "AssemblyGround[FirstR-1:Smooth Rod D10mm L400mm-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(82).translation = [92.141190007470314 373.29696367283253 77.611273327470798];  % mm
smiData.RigidTransform(82).angle = 0;  % rad
smiData.RigidTransform(82).axis = [0 0 0];
smiData.RigidTransform(82).ID = "AssemblyGround[FirstR-1:Top cover-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(83).translation = [92.141190007472673 396.29696367283191 77.611273327472318];  % mm
smiData.RigidTransform(83).angle = 1.5707963267949299;  % rad
smiData.RigidTransform(83).axis = [2.5786926783598233e-15 1 -3.2774599342926797e-16];
smiData.RigidTransform(83).ID = "AssemblyGround[FirstR-1:Z-axis Top Plate-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(84).translation = [58.553617901108389 26.296963672832796 44.023701221112333];  % mm
smiData.RigidTransform(84).angle = 3.1415926535897909;  % rad
smiData.RigidTransform(84).axis = [-0.92387953251128363 3.6565198030092576e-16 0.38268343236509755];
smiData.RigidTransform(84).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(85).translation = [58.553617901109476 -3.7030363271673137 111.19884543383414];  % mm
smiData.RigidTransform(85).angle = 1.6486078606222976;  % rad
smiData.RigidTransform(85).axis = [0 1 0];
smiData.RigidTransform(85).ID = "AssemblyGround[FirstR-1:Smooth Rod D10mm L400mm-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(86).translation = [125.72876211383294 396.29696367283202 44.023701221110393];  % mm
smiData.RigidTransform(86).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(86).axis = [-0.92387953251129129 1.7249842450488192e-15 -0.38268343236507885];
smiData.RigidTransform(86).ID = "AssemblyGround[FirstR-1:Smooth Rod Clamp-12]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(87).translation = [125.14119000746993 5.2969636728327494 77.611273327472134];  % mm
smiData.RigidTransform(87).angle = 0.60028263186057784;  % rad
smiData.RigidTransform(87).axis = [0 1 0];
smiData.RigidTransform(87).ID = "AssemblyGround[FirstR-1:Ball Bearing 608 - 8x22x7mm-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(88).translation = [79.641190007468865 -47.103036327167281 77.611273327473938];  % mm
smiData.RigidTransform(88).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(88).axis = [-0.4746765333633427 0 0.88016031987028331];
smiData.RigidTransform(88).ID = "AssemblyGround[FirstR-1:M4 Lock nut-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(89).translation = [92.141190007468921 -0.70303632716731124 65.111273327473981];  % mm
smiData.RigidTransform(89).angle = 2.9341041581660732;  % rad
smiData.RigidTransform(89).axis = [-0.10411805232530497 -0.70326361742236609 -0.70326361742236665];
smiData.RigidTransform(89).ID = "AssemblyGround[FirstR-1:M4 60mm - Bolts-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(90).translation = [92.141190007468893 -0.70303632716731124 90.111273327473938];  % mm
smiData.RigidTransform(90).angle = 2.9341041581660732;  % rad
smiData.RigidTransform(90).axis = [-0.10411805232530497 -0.70326361742236609 -0.70326361742236665];
smiData.RigidTransform(90).ID = "AssemblyGround[FirstR-1:M4 60mm - Bolts-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(91).translation = [92.141190007468836 -47.103036327167253 65.111273327473896];  % mm
smiData.RigidTransform(91).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(91).axis = [0.110141556964152 0 0.99391591064310492];
smiData.RigidTransform(91).ID = "AssemblyGround[FirstR-1:M4 Lock nut-3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(92).translation = [104.64119000746882 -47.103036327167295 77.611273327473853];  % mm
smiData.RigidTransform(92).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(92).axis = [-0.60226689715881054 0 0.79829479804562098];
smiData.RigidTransform(92).ID = "AssemblyGround[FirstR-1:M4 Lock nut-4]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(93).translation = [-30.805203689283189 -14.334378637027786 15.123887570325707];  % mm
smiData.RigidTransform(93).angle = 0;  % rad
smiData.RigidTransform(93).axis = [0 0 0];
smiData.RigidTransform(93).ID = "RootGround[ScaraBase-1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(34).mass = 0.0;
smiData.Solid(34).CoM = [0.0 0.0 0.0];
smiData.Solid(34).MoI = [0.0 0.0 0.0];
smiData.Solid(34).PoI = [0.0 0.0 0.0];
smiData.Solid(34).color = [0.0 0.0 0.0];
smiData.Solid(34).opacity = 0.0;
smiData.Solid(34).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.064728388743648529;  % kg
smiData.Solid(1).CoM = [8.4613756492745136 37.229085012052103 41.439290418027113];  % mm
smiData.Solid(1).MoI = [17.68173941270058 17.681748982167356 16.911701690701914];  % kg*mm^2
smiData.Solid(1).PoI = [0 0 -6.0115022078094808e-07];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "Stepper NEMA 17 -  20mm shaft*:*Stepper NEMA 17 -  20mm shaft";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.0022728637450558763;  % kg
smiData.Solid(2).CoM = [0 3.5 0];  % mm
smiData.Solid(2).MoI = [0.087027596832834384 0.15603683666322535 0.087027596832834384];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "Ball Bearing 608 - 8x22x7mm*:*Ball Bearing 608 - 8x22x7mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.50177004655013868;  % kg
smiData.Solid(3).CoM = [-5.8999762722733191 -5.0247167120684901 -0.25023945813250464];  % mm
smiData.Solid(3).MoI = [1160.6154640911641 3316.8460871706216 2314.1979586349935];  % kg*mm^2
smiData.Solid(3).PoI = [-5.8191758582985091 -5.7554431118261924 -13.272247285278629];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "Base*:*Base";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.017518235402808412;  % kg
smiData.Solid(4).CoM = [0 6.4999999999999991 2.4205113407986148e-08];  % mm
smiData.Solid(4).MoI = [5.961720199651924 11.379257842084453 5.9617299581135139];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 -6.212985557588389e-09];  % kg*mm^2
smiData.Solid(4).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "Thrust Bearing - 40x60x13*:*Thrust Bearing - 40x60x13";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.00071748980979339486;  % kg
smiData.Solid(5).CoM = [-5.4740898420992689e-13 3.7777881382943495 -9.5914604246974711e-13];  % mm
smiData.Solid(5).MoI = [0.014587332214200487 0.022254577707648226 0.014587330849548115];  % kg*mm^2
smiData.Solid(5).PoI = [0 -1.1818236125113242e-09 0];  % kg*mm^2
smiData.Solid(5).color = [0.62745098039215685 0.62745098039215685 0.62745098039215685];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "M8 Lock nut*:*M8 Lock nut";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.0030309640535650878;  % kg
smiData.Solid(6).CoM = [-3.7963675121564897 0 0];  % mm
smiData.Solid(6).MoI = [0.036124314478940128 0.7623136767964106 0.7623136742895732];  % kg*mm^2
smiData.Solid(6).PoI = [-9.4877131897027668e-10 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.62745098039215685 0.62745098039215685 0.62745098039215685];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "M8 45mm - Bolts*:*M8 45mm - Bolts";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.0052320712371415152;  % kg
smiData.Solid(7).CoM = [0 3.5000000000000004 0];  % mm
smiData.Solid(7).MoI = [1.1433013033716208 2.2465332618890401 1.1433013033716208];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = "Ball Bearing 35x47x7mm*:*Ball Bearing 30x42x7mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.0018089027332702198;  % kg
smiData.Solid(8).CoM = [0 -0.1397159425995709 -0.018906489205295144];  % mm
smiData.Solid(8).MoI = [0.060773752010209486 0.047638797985271659 0.060705998612140301];  % kg*mm^2
smiData.Solid(8).PoI = [2.5298285236911768e-05 0 0];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = "GT2 Pulley - Parametric*:*GT2 Pulley - Parametric";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 0.011387418297495065;  % kg
smiData.Solid(9).CoM = [0 6.0000000000000009 -2.6641710520374542e-07];  % mm
smiData.Solid(9).MoI = [2.9532265211819904 5.5874736874322606 2.9532309013910596];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 -5.729322682050772e-10];  % kg*mm^2
smiData.Solid(9).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = "Thrust Bearing 35x52x12mm*:*Thrust Bearing 35x52x12mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.0045940137691974324;  % kg
smiData.Solid(10).CoM = [0 3.5000000000000009 0];  % mm
smiData.Solid(10).MoI = [0.7827874025129441 1.5303919656417106 0.78278740251294388];  % kg*mm^2
smiData.Solid(10).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(10).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = "Ball Bearing 30x42x7mm*:*Ball Bearing 30x42x7mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.024598883371807378;  % kg
smiData.Solid(11).CoM = [0 1.2257590187689671 0];  % mm
smiData.Solid(11).MoI = [5.0404171627737009 8.4403660188440011 5.0404171627736938];  % kg*mm^2
smiData.Solid(11).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(11).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = "GT2 Pulley - 90 teeth - J3*:*GT2 Pulley - Parametric";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 0.041899115475407318;  % kg
smiData.Solid(12).CoM = [-0.76169882009232714 6.4469524475671873 -5.137894559024694e-13];  % mm
smiData.Solid(12).MoI = [15.02580755200904 27.431675650009765 14.892873682798491];  % kg*mm^2
smiData.Solid(12).PoI = [0 0 0.037385390138411356];  % kg*mm^2
smiData.Solid(12).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = "J3 Coupler*:*J3 Coupler";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 0.00013816784225542496;  % kg
smiData.Solid(13).CoM = [-3.3315126596706882e-12 2.3397968828285034 -1.9241187398377273e-12];  % mm
smiData.Solid(13).MoI = [0.00085665770796536107 0.001199612129390553 0.00085665777094128524];  % kg*mm^2
smiData.Solid(13).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(13).color = [0.62745098039215685 0.62745098039215685 0.62745098039215685];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = "M4 Lock nut*:*M4 Lock nut";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(14).mass = 0.10932143619930246;  % kg
smiData.Solid(14).CoM = [-75.035993495602312 4.0031577998765702 0.00011091448726133064];  % mm
smiData.Solid(14).MoI = [57.721995397406559 433.00293554148487 376.44684224610143];  % kg*mm^2
smiData.Solid(14).PoI = [3.8289369346584264e-08 0.0054052884570470949 0.090682964002973848];  % kg*mm^2
smiData.Solid(14).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(14).opacity = 1;
smiData.Solid(14).ID = "Arm 2 Cover*:*Arm 2 Cover";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(15).mass = 0.041742509407048212;  % kg
smiData.Solid(15).CoM = [7.6878243748152222e-07 12.441284392611129 0.00095355873435654039];  % mm
smiData.Solid(15).MoI = [8.0053611443062511 11.459722548370538 8.00544079034497];  % kg*mm^2
smiData.Solid(15).PoI = [-0.00097139520872781455 -6.4804584701418493e-09 3.3932776391505646e-07];  % kg*mm^2
smiData.Solid(15).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(15).opacity = 1;
smiData.Solid(15).ID = "NEMA 17 Stepper L24mm - 20mm shaft*:*NEMA 17 Stepper L24mm - 20mm shaft";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(16).mass = 0.022137362759501296;  % kg
smiData.Solid(16).CoM = [0 1.4884350840553 0];  % mm
smiData.Solid(16).MoI = [4.6555403904296506 7.8718215837914993 4.6555403904296471];  % kg*mm^2
smiData.Solid(16).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(16).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(16).opacity = 1;
smiData.Solid(16).ID = "GT2 Pulley - 92 teeth - J2*:*GT2 Pulley - Parametric";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(17).mass = 0.05615129525148637;  % kg
smiData.Solid(17).CoM = [-0.40470211278192508 7.3735343341575206 0.70096462126865655];  % mm
smiData.Solid(17).MoI = [24.252037915014579 44.117632340370228 23.302611195117201];  % kg*mm^2
smiData.Solid(17).PoI = [-0.073857822605481752 0.82222765846280821 0.042641833763024342];  % kg*mm^2
smiData.Solid(17).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(17).opacity = 1;
smiData.Solid(17).ID = "J2 Coupler*:*J2 Coupler";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(18).mass = 0.00064110747467502132;  % kg
smiData.Solid(18).CoM = [3.0597657742238096e-10 3.0598051201932113e-10 -22.267209880957388];  % mm
smiData.Solid(18).MoI = [0.13917652153672375 0.13917652153682802 0.0014181975048941659];  % kg*mm^2
smiData.Solid(18).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(18).color = [0.62745098039215685 0.62745098039215685 0.62745098039215685];
smiData.Solid(18).opacity = 1;
smiData.Solid(18).ID = "M4 50mm - Bolts*:*M4 50mm - Bolts";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(19).mass = 0.15447496018315413;  % kg
smiData.Solid(19).CoM = [-68.940203042199173 9.3761424903801469 0.0037119880458332034];  % mm
smiData.Solid(19).MoI = [118.9480447485185 752.21870665542554 658.30285550873964];  % kg*mm^2
smiData.Solid(19).PoI = [0.0025449468682690684 -0.0074200315464801334 2.4446149225114588];  % kg*mm^2
smiData.Solid(19).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(19).opacity = 1;
smiData.Solid(19).ID = "Arm 2*:*Arm 2";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(20).mass = 0.019228215459702675;  % kg
smiData.Solid(20).CoM = [0 3.9339404967300222 0];  % mm
smiData.Solid(20).MoI = [3.2427164049928492 6.0379530198056122 3.2427164049928421];  % kg*mm^2
smiData.Solid(20).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(20).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(20).opacity = 1;
smiData.Solid(20).ID = "GT2 Pulley - 22 - 80 teeth*:*GT2 Pulley - Parametric";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(21).mass = 0.17331219646739537;  % kg
smiData.Solid(21).CoM = [0 16.520599438298795 4.4193356675092881];  % mm
smiData.Solid(21).MoI = [259.09447032308179 431.81595053034943 238.67179748675304];  % kg*mm^2
smiData.Solid(21).PoI = [-6.4578628378682659 0 0];  % kg*mm^2
smiData.Solid(21).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(21).opacity = 1;
smiData.Solid(21).ID = "Z-axis Mount Platform*:*Z-axis Mount Platform";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(22).mass = 0.2034326419904634;  % kg
smiData.Solid(22).CoM = [-72.204714788863299 12.02779053784332 -0.10294643209329596];  % mm
smiData.Solid(22).MoI = [174.5303916585388 894.40487959272559 774.05430874295621];  % kg*mm^2
smiData.Solid(22).PoI = [0.20109558943542977 -1.1880049845288747 -0.75900614928000698];  % kg*mm^2
smiData.Solid(22).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(22).opacity = 1;
smiData.Solid(22).ID = "Arm 1*:*Arm 1";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(23).mass = 0.048238012720854304;  % kg
smiData.Solid(23).CoM = [-67.012136842966839 1.7579044985580974 0];  % mm
smiData.Solid(23).MoI = [24.587705928083384 182.84658563365326 158.48529056334814];  % kg*mm^2
smiData.Solid(23).PoI = [0 0 -0.12759050937821687];  % kg*mm^2
smiData.Solid(23).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(23).opacity = 1;
smiData.Solid(23).ID = "Arm 1 Cover*:*Arm 1 Cover";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(24).mass = 0.095590574847654486;  % kg
smiData.Solid(24).CoM = [0 4.9776558483013265 -1.1016295332253729];  % mm
smiData.Solid(24).MoI = [92.699121224434435 187.39055169383039 96.290206975023835];  % kg*mm^2
smiData.Solid(24).PoI = [0.072837339916972513 0 0];  % kg*mm^2
smiData.Solid(24).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(24).opacity = 1;
smiData.Solid(24).ID = "Z-axis Bottom Plate*:*Z-axis Bottom Plate";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(25).mass = 0.0082249628992412029;  % kg
smiData.Solid(25).CoM = [0 7 -0.95136403936202085];  % mm
smiData.Solid(25).MoI = [0.53368365375383686 1.2347211549689741 0.97536919983453563];  % kg*mm^2
smiData.Solid(25).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(25).color = [0.058823529411764705 0.60392156862745094 1];
smiData.Solid(25).opacity = 1;
smiData.Solid(25).ID = "Smooth Rod Clamp*:*Smooth Rod Clamp";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(26).mass = 0.037500177497679192;  % kg
smiData.Solid(26).CoM = [0 1.1179573721085745 0];  % mm
smiData.Solid(26).MoI = [11.086703516641544 19.518364703236415 11.086703516641537];  % kg*mm^2
smiData.Solid(26).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(26).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(26).opacity = 1;
smiData.Solid(26).ID = "GT2 Pulley - 110 teeth - J1*:*GT2 Pulley - Parametric";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(27).mass = 0.00076677118080121056;  % kg
smiData.Solid(27).CoM = [3.5223031063004767e-10 3.5223435795848833e-10 -27.264126220527125];  % mm
smiData.Solid(27).MoI = [0.23802692727901653 0.23802692727916011 0.0016695249164505907];  % kg*mm^2
smiData.Solid(27).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(27).color = [0.62745098039215685 0.62745098039215685 0.62745098039215685];
smiData.Solid(27).opacity = 1;
smiData.Solid(27).ID = "M4 60mm - Bolts*:*M4 60mm - Bolts";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(28).mass = 0.041489713327801492;  % kg
smiData.Solid(28).CoM = [-0.020923982344609557 4.9152997133161467 0];  % mm
smiData.Solid(28).MoI = [50.597910819629547 98.251720425684127 50.686921663898893];  % kg*mm^2
smiData.Solid(28).PoI = [0 0 -0.041509522227205546];  % kg*mm^2
smiData.Solid(28).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(28).opacity = 1;
smiData.Solid(28).ID = "Base cover*:*Base cover";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(29).mass = 0.11408148319697993;  % kg
smiData.Solid(29).CoM = [-0.037588801499445323 1.1156410749205785 -0.14028331699156368];  % mm
smiData.Solid(29).MoI = [92.214267205203257 175.98015321751703 91.678932990743704];  % kg*mm^2
smiData.Solid(29).PoI = [-0.1178777227181626 -0.15453767641233149 -0.03158524060795017];  % kg*mm^2
smiData.Solid(29).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(29).opacity = 1;
smiData.Solid(29).ID = "J1 coupler*:*J1 coupler";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(30).mass = 0.031415926535897941;  % kg
smiData.Solid(30).CoM = [0 199.99999999999997 0];  % mm
smiData.Solid(30).MoI = [419.07537001948822 0.39269908169872442 419.07537001948822];  % kg*mm^2
smiData.Solid(30).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(30).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(30).opacity = 1;
smiData.Solid(30).ID = "Smooth Rod D10mm L400mm*:*Smooth Rod D10mm L400mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(31).mass = 0.045156744568850903;  % kg
smiData.Solid(31).CoM = [0.38959714017989061 5.9092653705066791 -0.031746501236239691];  % mm
smiData.Solid(31).MoI = [62.444256830953357 110.24573825105387 52.014379144360134];  % kg*mm^2
smiData.Solid(31).PoI = [-0.0066816362211883085 -0.037831907722561613 -0.071682433862132897];  % kg*mm^2
smiData.Solid(31).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(31).opacity = 1;
smiData.Solid(31).ID = "Top cover*:*Top cover";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(32).mass = 0.086649438368773549;  % kg
smiData.Solid(32).CoM = [0.15489942438149198 3.5520146288124006 -2.5245752355417133];  % mm
smiData.Solid(32).MoI = [77.601894374186614 155.41852241460063 79.759412977937245];  % kg*mm^2
smiData.Solid(32).PoI = [-0.93774457914351961 0.34192982968408137 0.14980457808463071];  % kg*mm^2
smiData.Solid(32).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(32).opacity = 1;
smiData.Solid(32).ID = "Z-axis Top Plate*:*Z-axis Top Plate";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(33).mass = 0.019100883333825931;  % kg
smiData.Solid(33).CoM = [0 190.00000000000003 0];  % mm
smiData.Solid(33).MoI = [229.92369965037406 0.15280706667060739 229.92369965037406];  % kg*mm^2
smiData.Solid(33).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(33).color = [0.7803921568627451 0.76078431372549016 0.74117647058823533];
smiData.Solid(33).opacity = 1;
smiData.Solid(33).ID = "Lead Screw D8mm L380mm*:*Lead Screw D8mm L380mm";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(34).mass = 0.015305903553437779;  % kg
smiData.Solid(34).CoM = [6.6245699220001194e-06 1.9847415170193785e-05 66.739180468823093];  % mm
smiData.Solid(34).MoI = [28.790855514805109 28.790563289200747 0.30424704327891167];  % kg*mm^2
smiData.Solid(34).PoI = [3.5661589925355613e-06 1.1902945344894795e-06 -0.001839525977229904];  % kg*mm^2
smiData.Solid(34).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(34).opacity = 1;
smiData.Solid(34).ID = "drill bit*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(2).Rz.Pos = 0.0;
smiData.CylindricalJoint(2).Pz.Pos = 0.0;
smiData.CylindricalJoint(2).ID = "";

smiData.CylindricalJoint(1).Rz.Pos = 157.77570890620228;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = "[Lead Screw D8mm L380mm-4:-:Link3-2]";

smiData.CylindricalJoint(2).Rz.Pos = -22.2242910937975;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = "[FirstR-1:-:Lead Screw D8mm L380mm-4]";


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(8).Rz.Pos = 0.0;
smiData.RevoluteJoint(8).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -127.89380106505739;  % deg
smiData.RevoluteJoint(1).ID = "[ScaraBase-1:-:GT2 Pulley - Parametric-4]";

smiData.RevoluteJoint(2).Rz.Pos = 5.112056101503601;  % deg
smiData.RevoluteJoint(2).ID = "[Link4-2:-:GT2 Pulley - Parametric-5]";

smiData.RevoluteJoint(3).Rz.Pos = -30.000000000168768;  % deg
smiData.RevoluteJoint(3).ID = "[Link4-2:-:DrillingEE-1]";

smiData.RevoluteJoint(4).Rz.Pos = 149.99999999983146;  % deg
smiData.RevoluteJoint(4).ID = "[Link3-2:-:Link4-2]";

smiData.RevoluteJoint(5).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(5).ID = "[ScaraBase-1:-:FirstR-1]";

smiData.RevoluteJoint(6).Rz.Pos = 0.84893612214585368;  % deg
smiData.RevoluteJoint(6).ID = "[ScaraBase-1:-:GT2 Pulley - 22 - 80 teeth-4]";

smiData.RevoluteJoint(7).Rz.Pos = 1.2722218725853882e-14;  % deg
smiData.RevoluteJoint(7).ID = "[FirstR-1:-:Stepper NEMA 17 -  20mm shaft-1]";

smiData.RevoluteJoint(8).Rz.Pos = -123.15761964092391;  % deg
smiData.RevoluteJoint(8).ID = "[DrillingEE-1:-:drill bit-1]";

