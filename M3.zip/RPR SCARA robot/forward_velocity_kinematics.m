function X_dot = forward_velocity_kinematics(q, q_dot)
    % Obtain the Jacobian matrix for the current joint configuration
    J = numeric_jacobian_func(q(1), q(2), q(3));
    
    % Multiply the Jacobian matrix with q_dot to obtain end-effector velocity
    X_dot = J * q_dot;
end