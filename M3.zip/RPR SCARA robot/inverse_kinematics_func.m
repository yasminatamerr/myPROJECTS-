function q = inverse_kinematics_func(q0, X_desired)
    tolerance = 1e-6;
    max_iterations = 100;
    q = q0; % Initial guess for joint angles

    % % Link lengths
    % L1 = 0.645;
    % L2 = 0.228;
    % L3 = 0.1365;
    % L4 = L1 + 0.1 - 0.031;

    for i = 1:max_iterations
        % Compute forward kinematics with current q
        X_current = forward_Position_kinematics(q(1), q(2), q(3));

        % Calculate error
        error = X_desired - X_current;
        
        % Break if error is within tolerance
        if norm(double(error)) < tolerance
            break;
        end

        % Compute inverse Jacobian
        J_inv = inverse_jacobian_matrix(q);

        % Update joint angles
        q = q + J_inv * error(:); % Ensure `error` is a column vector
    end
end
