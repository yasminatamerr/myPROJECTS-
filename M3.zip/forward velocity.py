def forward_velocity_kinematics(q, q_dot):
    """
    Calculate the end-effector velocity given joint configurations and velocities.
    
    Parameters:
        q (array): Joint angles [q1, q2, q3].
        q_dot (array): Joint velocities [q1_dot, q2_dot, q3_dot].
    
    Returns:
        np.ndarray: End-effector velocity.
    """
    # Obtain the Jacobian matrix for the current joint configuration
    J = jacobian_matrix(q)
    
    # Multiply the Jacobian matrix with q_dot to obtain end-effector velocity
    V_F = np.dot(J, q_dot)  # V_F = J * q_dot
    
    return V_F