def jacobian_matrix(q):
    """
    Calculate the Jacobian matrix using numerical differentiation.
    
    Parameters:
        q (array): Joint angles [q1, q2, q3].
    
    Returns:
        np.ndarray: Jacobian matrix.
    """
    # Define link lengths (optional since they're in forward kinematics)
    L1 = 0.645
    L2 = 0.228
    L3 = 0.1365
    L4 = L1 + 0.1 - 0.031

    # Calculate forward kinematics for the current joint angles
    X = forward_position_kinematics(q[0], q[1], q[2])

    # Initialize the Jacobian matrix
    J = np.zeros((3, 3))  # 3x3 matrix for 3D end-effector space

    delta = 1e-6  # Small perturbation for numerical derivative

    for i in range(3):
        q_temp = np.array(q, copy=True)
        q_temp[i] += delta  # Perturb each joint variable

        # Recalculate the forward kinematics for the perturbed joint
        X_perturbed = forward_position_kinematics(q_temp[0], q_temp[1], q_temp[2])
        
        # Numerical derivative using central difference
        J[:, i] = (X_perturbed - X) / delta

    return J