Need to run both numeric_jacobian_func.m and ScaraRobot_DataFile.m before running Simscape model

Simscape video has all needed illustration
All MATLAB files are in RPR SCARA robot folder
